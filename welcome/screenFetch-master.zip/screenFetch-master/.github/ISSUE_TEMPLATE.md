<!--
PLEASE FILL THE FOLLOWING INFORMATION
-->

**I'm submitting a ...**  (check one with "x")
```
[ ] bug report
[ ] new distro request
```

**Bug report**
```
=> search Github for a similar issue or PR before submitting
=> download the latest revision from Github and check if the bug is still present
   -> https://github.com/KittyKatt/screenFetch/raw/master/screenfetch-dev
=> Show us the output of: screenfetch -v
```

**New distro request**
```
Distro name: 
Homepage: 
Distro logo: 
Package manager: 

Show us the output of
 => lsb_release -sirc
 => cat /etc/os-release
 => ls -1 /etc/*-release
```

